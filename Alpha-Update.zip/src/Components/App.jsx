import React, { Component } from 'react';
import { Container, Header } from 'semantic-ui-react';
import Challenges from './Challenges';

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      authenticated: false,
      page: 'login',
    };
  }

  render() {
    return (
      <div className="fullscreen-container homepage">
        <Container fluid textAlign="center" id="homepage-container">
          <Header as="h1" id="welcome-header">
            BattlePass Challenge Tracker
          </Header>
          <Challenges />
        </Container>
      </div>
    );
  }
}

export default App;
